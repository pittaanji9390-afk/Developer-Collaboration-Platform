// Generator script init
